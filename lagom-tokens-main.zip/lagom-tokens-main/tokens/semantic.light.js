const tokens = require("./tokens.studio.json");
module.exports = tokens["semantic-light"];
