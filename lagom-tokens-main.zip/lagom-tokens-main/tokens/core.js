const { core } = require("./tokens.studio.json");
module.exports = core;
