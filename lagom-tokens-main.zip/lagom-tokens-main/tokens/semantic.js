const { semantic } = require("./tokens.studio.json");
module.exports = semantic;
