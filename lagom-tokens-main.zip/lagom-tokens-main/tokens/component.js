const { component } = require("./tokens.studio.json");
module.exports = component;
