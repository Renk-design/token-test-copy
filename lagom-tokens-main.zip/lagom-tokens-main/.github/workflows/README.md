# Github Actions

## References

[Quickstart for Github Actions](https://docs.github.com/en/actions/quickstart)

[Building and testing Node.js](https://docs.github.com/en/actions/automating-builds-and-tests/building-and-testing-nodejs)

[Publishing Node.js packages](https://docs.github.com/en/actions/publishing-packages/publishing-nodejs-packages)

[Github Action for Yarn](https://github.com/marketplace/actions/github-action-for-yarn)
